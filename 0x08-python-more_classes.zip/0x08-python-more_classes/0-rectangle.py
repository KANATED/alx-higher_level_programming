#!/usr/bin/python3
"""
Defines an empty Rectangle class.
"""


class Rectangle:
    """Empty Rectangle class."""
    pass
